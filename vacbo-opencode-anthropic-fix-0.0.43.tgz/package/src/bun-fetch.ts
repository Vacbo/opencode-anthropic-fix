// ---------------------------------------------------------------------------
// Bun TLS proxy manager — spawns a Bun subprocess for BoringSSL TLS.
// ---------------------------------------------------------------------------

import { execFileSync, spawn } from "node:child_process";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

let proxyPort: number | null = null;
let proxyProcess: ReturnType<typeof spawn> | null = null;
let starting: Promise<number | null> | null = null;

function findProxyScript(): string | null {
  const dir = typeof __dirname !== "undefined" ? __dirname : dirname(fileURLToPath(import.meta.url));
  for (const candidate of [
    join(dir, "bun-proxy.mjs"),
    join(dir, "..", "dist", "bun-proxy.mjs"),
    join(dir, "bun-proxy.ts"),
  ]) {
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

function hasBun(): boolean {
  try {
    execFileSync("which", ["bun"], { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

export async function ensureBunProxy(): Promise<number | null> {
  // Skip proxy in test environments
  if (process.env.VITEST || process.env.NODE_ENV === "test") return null;
  if (proxyPort) return proxyPort;
  if (starting) return starting;

  starting = new Promise<number | null>((resolve) => {
    const script = findProxyScript();
    if (!script || !hasBun()) {
      resolve(null);
      starting = null;
      return;
    }

    try {
      const child = spawn("bun", ["run", script, "0"], {
        stdio: ["ignore", "pipe", "ignore"],
        detached: false,
      });
      proxyProcess = child;

      let done = false;
      child.stdout?.on("data", (chunk: Buffer) => {
        const m = chunk.toString().match(/BUN_PROXY_PORT=(\d+)/);
        if (m && !done) {
          done = true;
          proxyPort = parseInt(m[1], 10);
          resolve(proxyPort);
        }
      });
      child.on("error", () => {
        if (!done) { done = true; resolve(null); }
        proxyPort = null; proxyProcess = null; starting = null;
      });
      child.on("exit", () => {
        proxyPort = null; proxyProcess = null; starting = null;
        if (!done) { done = true; resolve(null); }
      });
      setTimeout(() => {
        if (!done) { done = true; resolve(null); }
      }, 5000);
    } catch {
      resolve(null);
      starting = null;
    }
  });

  return starting;
}

export function stopBunProxy(): void {
  if (proxyProcess) {
    try { proxyProcess.kill(); } catch { /* already dead */ }
    proxyProcess = null; proxyPort = null; starting = null;
  }
}

/**
 * Fetch via Bun proxy for BoringSSL TLS fingerprint.
 * Falls back to native Node fetch if Bun is unavailable.
 */
export async function fetchViaBun(
  input: string | URL | Request,
  init: { headers: Headers; body?: string | null; method?: string; [k: string]: unknown },
): Promise<Response> {
  const port = await ensureBunProxy();
  const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;

  if (!port) return fetch(input, init as RequestInit);

  const headers = new Headers(init.headers);
  headers.set("x-proxy-url", url);

  return fetch(`http://127.0.0.1:${port}/`, {
    method: init.method || "POST",
    headers,
    body: init.body,
  });
}
